# User Credentials
host = 'localhost'
user = 'Your Username here'
password = 'Your Password here'
database = 'contact_management'
